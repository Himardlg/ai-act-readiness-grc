# Architecture

The MVP is a single-page application implemented in `index.html` with inline CSS and JavaScript. It does not require a build step, external JavaScript libraries or a backend.

## Data model

The app stores three collections in browser `localStorage`:

- `projects`
- `assessments`
- `risks`

The JSON export contains an application name, schema version, export timestamp and data object.

## Important limitations

- Local data is tied to the browser/profile and may behave differently when opened from a local file.
- There is no authentication, authorization, multi-user collaboration or server-side backup.
- Local storage is not encrypted by this application.
- Imported JSON replaces the current app data after confirmation.
- This data model is intended for demonstration and should not be treated as production storage.
