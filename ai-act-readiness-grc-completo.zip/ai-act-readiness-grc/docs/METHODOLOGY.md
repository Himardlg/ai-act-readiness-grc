# Methodology and Scope

## 1. Purpose

This prototype explores how organizations might structure preliminary activities related to AI governance, risk management and regulatory readiness. It is a workflow prototype, not a validated legal assessment methodology.

## 2. Conceptual workflow

1. Define the project and its scope.
2. Identify relevant AI systems and stakeholders.
3. Gather available information and evidence.
4. Identify potential gaps and risks.
5. Record mitigation actions, owners and target dates.
6. Review progress as new evidence becomes available.

Not every step is implemented in the current application.

## 3. Regulatory mapping

Future assessment criteria should be mapped to relevant provisions of Regulation (EU) 2024/1689 and applicable official guidance. Each criterion should document its identifier, legal reference, applicability, expected evidence, status, rationale, reviewer and review date.

Mappings should be reviewed when legislation, guidance or assumptions change.

## 4. Risk management

A more mature risk register could capture the affected system, impact, likelihood, severity, existing controls, mitigation measures, owner, due date, status and supporting evidence. Any scoring model should be documented and validated before operational use.

## 5. Evidence and traceability

Readiness conclusions should be supported by evidence. A production implementation would need appropriate access controls, change history, evidence versioning, backups and audit logging.

The standalone prototype should not be assumed to provide enterprise-grade auditability or secure centralized storage.

## 6. Limitations

The prototype does not replace legal advice, an independent audit or an organization's accountability for compliance. A readiness assessment is not equivalent to a declaration or certification of conformity.
